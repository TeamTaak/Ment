<footer>
	<p class="center">&copy; 2017 Ment</p>
</footer>